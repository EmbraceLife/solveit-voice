// ═══════════════════════════════════════════════════════════════════════
// Voice Widget Module: Save Toggle — The Bookmark & Downloader
// ═══════════════════════════════════════════════════════════════════════

if (!window.__voiceSaveToggleInit) {
window.__voiceSaveToggleInit = true;

(function() {
const V = window._voice;
if (!V) { console.error('[SaveToggle] No voice widget'); return; }
if (window._saveToggleCleanup) window._saveToggleCleanup();

const LS_KEY = 'tts_saved_hashes';

function getSaved() {
    try { return new Set(JSON.parse(localStorage.getItem(LS_KEY) || '[]')); }
    catch(e) { return new Set(); }
}
function toggleSaved(h) {
    const saved = getSaved();
    const nowSaved = !saved.has(h);
    if (nowSaved) saved.add(h); else saved.delete(h);
    localStorage.setItem(LS_KEY, JSON.stringify([...saved]));
    return nowSaved;
}

const bookmarkBtn = document.createElement('button');
bookmarkBtn.style.cssText = 'display:none;font-size:1.1em;border:none;border-radius:8px;padding:4px 8px;cursor:pointer;margin-left:2px;transition:all 0.2s';
let currentHash = null;

function renderBookmark() {
    if (!currentHash) { bookmarkBtn.style.display = 'none'; return; }
    const saved = getSaved().has(currentHash);
    bookmarkBtn.textContent = saved ? '★' : '☆';
    bookmarkBtn.style.display = 'inline';
    bookmarkBtn.style.background = saved ? 'rgba(255,220,100,0.3)' : 'rgba(255,255,255,0.08)';
    bookmarkBtn.style.color = saved ? '#ffd93d' : '#888';
    bookmarkBtn.title = saved ? 'Saved — click to unsave' : 'Click to save this audio';
}

bookmarkBtn.onclick = async () => {
    if (!currentHash) return;
    
    // Get the audio URL
    const audioEl = document.querySelector('#kokoro-audio-container audio');
    const audioUrl = audioEl?.getAttribute('src');
    if (!audioUrl) {
        alert('No audio to save!');
        return;
    }
    
    // Ask user for filename
    const defaultName = 'kokoro_' + currentHash.slice(0, 8);
    const filename = prompt('Name this audio file:', defaultName);
    if (!filename) return;
    
    // Show saving status
    bookmarkBtn.textContent = '⏳';
    
    try {
        // Fetch the audio file as blob
        const response = await fetch(audioUrl);
        const blob = await response.blob();
        const sizeMB = (blob.size / 1024 / 1024).toFixed(2);
        
        // Create download link
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = filename + '.wav';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(blobUrl);
        
        // Mark as saved locally
        toggleSaved(currentHash);
        renderBookmark();
        
        alert(`✅ Downloaded "${filename}.wav" (${sizeMB} MB)`);
        
    } catch (e) {
        console.error('[SaveToggle] Download failed:', e);
        alert('❌ Download failed: ' + e.message);
        renderBookmark();
    }
};


// Insert star button after play button (with polling)
function attachBookmarkButton() {
    const widget = document.getElementById('voice-widget');
    if (!widget) {
        setTimeout(attachBookmarkButton, 100);
        return;
    }
    const playBtn = [...widget.querySelectorAll('button')].find(b => b.textContent === '▶');
    if (playBtn) {
        playBtn.after(bookmarkBtn);
        console.log('[SaveToggle] ☆/★ attached');
    } else {
        setTimeout(attachBookmarkButton, 100);
    }
}
attachBookmarkButton();

// Watch audio container for hash extraction
function watchAudioContainer() {
    const audioEl = document.querySelector('#kokoro-audio-container audio');
    if (audioEl) {
        const obs = new MutationObserver(() => {
            const src = audioEl.getAttribute('src') || '';
            const m = src.match(/\/([a-zA-Z0-9_-]+)\/output\.wav/);
            if (m) { currentHash = m[1]; }
            else if (src.startsWith('blob:')) { currentHash = 'blob-' + Date.now(); }
            else { currentHash = null; }
            renderBookmark();
        });

        obs.observe(audioEl, { attributes: true, attributeFilter: ['src'] });
        window._saveToggleCleanup = () => {
            obs.disconnect(); bookmarkBtn.remove();
            window.__voiceSaveToggleInit = false;
        };
    } else {
        setTimeout(watchAudioContainer, 100);
    }
}
watchAudioContainer();

V.log('[SaveToggle] ✅ ready with download support');

})();
}
