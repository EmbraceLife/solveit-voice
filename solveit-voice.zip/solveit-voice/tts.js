// ═══════════════════════════════════════════════════════════════════════
// Voice Widget Module: Browser TTS — The Voice
//
// DESIGN: Watches for AI prompt responses via htmx:wsAfterMessage,
// extracts prose text (skipping code blocks), and speaks it using
// the browser's built-in speechSynthesis API.
//
// This is the DEFAULT TTS. When Kokoro is enabled (kokoro.js),
// it intercepts speechSynthesis.speak() and uses Replicate instead.
// ═══════════════════════════════════════════════════════════════════════

if (!window.__voiceTtsInit) {
window.__voiceTtsInit = true;

(function() {
const V = window._voice;
if (!V) { console.error('[TTS] No voice widget'); return; }

const log = V.log;

// --- Text extraction: skip code blocks and details sections ---
const ttsSkipTags = new Set(['DETAILS']);

function extractProseText(proseEl) {
    const tw = document.createTreeWalker(proseEl, NodeFilter.SHOW_TEXT, {
        acceptNode: (n) => {
            let p = n.parentElement;
            while (p && p !== proseEl) {
                if (ttsSkipTags.has(p.tagName) || p.classList.contains('cm-editor')) return NodeFilter.FILTER_REJECT;
                p = p.parentElement;
            }
            return NodeFilter.FILTER_ACCEPT;
        }
    });
    let text = '';
    while (tw.nextNode()) text += tw.currentNode.textContent;
    // FIXED: only strip control chars, preserve all Unicode (Chinese, accented, etc.)
    return text.replace(/[\0-\x08\x0b\x0c\x0e-\x1f]/g, '').trim().slice(0, 10000);
}
// Expose for kokoro.js and save-toggle.js
V._extractProseText = extractProseText;


function speakText(text) {
    // Guard: don't talk over voice command or hidden tab
    if (V.isWakeActive && V.isWakeActive()) { log('TTS suppressed: wake active'); return; }
    if (V._tabHidden) { log('TTS suppressed: tab hidden'); return; }
    log('TTS speaking:', text.slice(0, 50));
    V.speaking = true;
    if (V.resetWakeState) V.resetWakeState();
    speechSynthesis.cancel();

    // Split text into 200-character chunks to stay under Chrome's 15-second limit
    const CHUNK_SIZE = 800;
    const chunks = [];
    for (let i = 0; i < text.length; i += CHUNK_SIZE) {
        chunks.push(text.substring(i, i + CHUNK_SIZE));
    }
    log('TTS chunks:', chunks.length);

    // Pick voice once — same voice for all chunks
    const voices = speechSynthesis.getVoices();
    const hasChinese = /[\u4e00-\u9fff]/.test(text);
    let voice = null;
    let preferredNames, googleFallback;
    if (hasChinese) {
        preferredNames = ['Mei Jia', 'Li-Mu', 'Yu-shu'];
        googleFallback = 'Google 普通话';
    } else {
        preferredNames = ['Daniel', 'Jamie', 'Aaron'];
        googleFallback = 'Google UK English Female';
    }
    for (const name of preferredNames) {
        voice = voices.find(v => v.name.includes(name));
        if (voice) break;
    }
    if (!voice) {
        voice = voices.find(v => v.name.includes(googleFallback));
    }

    // Chain chunks: after one finishes, start the next
    let chunkIndex = 0;
    const speakNext = () => {
        if (!V.speaking || chunkIndex >= chunks.length) {
            V.ttsEnd();
            return;
        }
        const utt = new SpeechSynthesisUtterance(chunks[chunkIndex]);
        if (voice) utt.voice = voice;
        utt.rate = V.CFG.ttsRate;
        utt.onend = () => {
            chunkIndex++;
            setTimeout(() => speakNext(), 0);
        };
        utt.onerror = (e) => { log('TTS chunk error:', e.error); V.ttsEnd(); };
        V.ttsStopBtn.style.display = 'inline';
        speechSynthesis.speak(utt);
    };

    // Small delay needed after cancel() — Chrome bug
    setTimeout(() => speakNext(), 50);
}


V._speakText = speakText;

// --- Poll-based response watcher ---
function watchForResponse(id) {
    V.clearTtsWatch();
    let lastText = '';
    let stableCount = 0;
    let stableThreshold = 12;  // 6s default, upgrades to 10s for tool calls
    const containerSel = `#${id}-o`;

    const poll = setInterval(() => {
        const container = document.querySelector(containerSel);
        if (!container) return;
        const proseEl = container.querySelector('.prose');
        if (!proseEl) return;
        if (stableThreshold < 20 && proseEl.querySelector('details')) stableThreshold = 20;
        const text = extractProseText(proseEl);
        log('TTS poll:', { len: text.length, stable: stableCount, threshold: stableThreshold });
        if (text.length === 0) return;
        if (text === lastText) {
            if (++stableCount >= stableThreshold) {
                V.clearTtsWatch();
                speakText(text);
            }
        } else { lastText = text; stableCount = 0; }
    }, 500);
    V._setTtsPoll(poll);
    V._setTtsSafety(setTimeout(() => V.clearTtsWatch(), 300000));
}

// --- Listen for prompt responses via htmx WebSocket messages ---
const wsListener = (e) => {
    if (!V.userActive) return;
    if (V._tabHidden) { log('TTS watcher blocked: tab hidden'); return; }
    const html = e.detail.message;
    if (!html.includes('data-mtype="prompt"')) return;
    const isVoice = html.includes('🎤');
    if (isVoice && !V.ttsCb.checked) return;
    if (!isVoice && !V.ttsManualCb.checked) return;
    const idMatch = html.match(/id="(_[a-f0-9]+)"/);
    if (!idMatch) return;
    log('TTS check:', idMatch[1]);
    watchForResponse(idMatch[1]);
};
document.body.addEventListener('htmx:wsAfterMessage', wsListener, { signal: V.widget._voiceAc?.signal });

// Cleanup is handled by V.clearTtsWatch and main widget cleanup
log('✅ Browser TTS module loaded');
})();

}
